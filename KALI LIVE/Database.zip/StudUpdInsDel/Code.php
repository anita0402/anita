<?
// echo "<pre>";
// print_r($_REQUEST);
// print_r($_POST);
mysql_connect("localhost","root","");
mysql_select_db("dbbatch11to1");
 $rollno=$_REQUEST["txtrollno"];
 $name=$_REQUEST["txtname"];
 $class=$_REQUEST["txtclass"];
 $address=$_REQUEST["txtaddress"];
 $city=$_REQUEST["txtcity"];
 if(isset($_REQUEST["btnadd"]))
 {
 	 $str="insert into tbstud(sname,sclass,saddress,scity) values('$name','$class','$address','$city')";
	 //echo $str;
	 	mysql_query($str);
 }
 else  if(isset($_REQUEST["btnupdate"]))
 {
  	 $str="update  tbstud set sname='$name', sclass='$class', saddress='$address', scity='$city'  where srollno=$rollno";
	 //echo $str;
	 	mysql_query($str);

 }
 else  if(isset($_REQUEST["btndelete"]))
 {
   	 $str="delete from  tbstud   where srollno=$rollno";
	 //echo $str;
	 	mysql_query($str);


 }
header("location:Desg.php");
 

?>