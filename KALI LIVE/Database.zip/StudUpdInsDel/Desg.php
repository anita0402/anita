<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<?
mysql_connect("localhost","root","")or die("Check connection ");
mysql_select_db("dbbatch11to1")or die("Check database");
?>
<body>
<form id="form1" name="form1" method="post" action="Code.php">
  <table width="70%" border="0" align="center">
    <tr>
      <th scope="row"><div align="right">Rollno</div></th>
      <td><input name="txtrollno" type="text" id="txtrollno" /></td>
    </tr>
    <tr>
      <th scope="row"><div align="right">Name</div></th>
      <td><input name="txtname" type="text" id="txtname" /></td>
    </tr>
    <tr>
      <th scope="row"><div align="right">Class</div></th>
      <td><input name="txtclass" type="text" id="txtclass" /></td>
    </tr>
    <tr>
      <th scope="row"><div align="right">Address</div></th>
      <td><input name="txtaddress" type="text" id="txtaddress" /></td>
    </tr>
    <tr>
      <th scope="row"><div align="right">City</div></th>
      <td><input name="txtcity" type="text" id="txtcity" /></td>
    </tr>
    <tr>
      <th scope="row"><div align="right">
        <input name="btnadd" type="submit" id="btnadd" value="Add" />
      </div></th>
      <td><input name="btnupdate" type="submit" id="btnupdate" value="Update" />
      <input name="btndelete" type="submit" id="btndelete" value="Delete" /></td>
    </tr>
    <tr>
      <th colspan="2" scope="row"><table width="100%" border="1">
        <tr>
          <th scope="col">Sr.No</th>
          <th scope="col">Rollno</th>
          <th scope="col">Name</th>
          <th scope="col">Class</th>
          <th scope="col">Address</th>
          <th scope="col">City</th>
        </tr>
		<?
		$str="select * from tbstud";
		$rs=mysql_query($str)or die("Check query");
//		echo $rs;
	//	echo "<pre>";
		//print_r(mysql_fetch_object($rs));
		$srno=1;
		while($row=mysql_fetch_array($rs))
		{
		?>
        <tr>
          <td><?=$srno++?></td>
          <td><?=$row["SRollno"]?></td>
          <td><?=$row["SName"]?></td>
          <td><?=$row["SClass"]?></td>
          <td><?=$row["SAddress"]?></td>
          <td><?=$row["SCity"]?></td>
        </tr>
		<?
		}
		?>
      </table></th>
    </tr>
  </table>
</form>
</body>
</html>
